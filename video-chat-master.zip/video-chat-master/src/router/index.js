import Vue from 'vue'
import Router from 'vue-router'
import VueMaterial from 'vue-material'
import 'vue-material/dist/vue-material.min.css'
import 'vue-material/dist/theme/default.css' // This line here
import VueToastr from "vue-toastr"

import Home from './../views/Home.vue'
import store from '../store'

Vue.use(VueMaterial)
Vue.use(VueToastr, {
  defaultPosition: "toast-top-left",
  defaultTimeout: 3000,
  defaultProgressBar: false,
  defaultProgressBarValue: 0,
})
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home,
      beforeEnter: (to, from, next) => {
        store.state.room && store.state.username ? next('/chat') : next()
      }
    },
    {
      path: '/chat',
      name: 'chat',
      // route level code-splitting
      // this generates a separate chunk (about.[hash].js) for this route
      // which is lazy-loaded when the route is visited.
      component: () => import(/* webpackChunkName: "about" */ './../views/Chat.vue'),
      beforeEnter: (to, from, next) => {
        !store.state.room && !store.state.username ? next('/') : next()
      }
    }
  ]
})
