module.exports = {
    productionSourceMap: false
};