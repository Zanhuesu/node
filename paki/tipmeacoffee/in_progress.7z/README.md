# TipMeACoffee
TipMeACoffee is next generation social media platform developed by community for community and run under Breeze Foundation DAO.
TipMeACoffee web front is developed on top of Breeze Blockchain with proof of likes mechanism. 

## Installation
TipMeACoffee is a node.js application developed using ExpressJs framework.
To run

```
git clone https://github.com/breeze-foundation/tipmeacoffee.git
cd tipmeacoffee
npm i -g
node app.js
```

## Issues
To report a non-critical issue, please file an issue on this GitHub project.
If you find a security issue please report details to trusted community members.
We will evaluate the risk and make a patch available before filing the issue.