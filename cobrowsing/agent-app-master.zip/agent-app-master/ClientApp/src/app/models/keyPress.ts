export interface IKeyPress {
    id: string;
    key: string;
}
