declare namespace NodeJS {
  interface ProcessEnv {
    REACT_APP_SIGNALING_SERVER: string
    REACT_APP_STUN_SERVERS: string
    REACT_APP_TURN_SERVERS: string
    REACT_APP_TURN_USERNAME: string
    REACT_APP_TURN_CREDENCIAL: string
  }
}
