# Collaborative-ide :computer::heart_eyes::+1:
This is Interview.io  is an collaborative ide build for collab with fellow engineers/friends or practise interviews to ace the ds &amp; algo interviews.

# Quick overview of this project through images :zap::fire:
   <p align="center"><b>Login Screens</b>:tv: </p>
<p float="left">
  <img src="https://github.com/mehulsatardekar/Collaborative-ide/blob/main/screenshots/login_page1.png" width="500">
  <img src="https://github.com/mehulsatardekar/Collaborative-ide/blob/main/screenshots/login_page2.png" width="500">
  <img src="https://github.com/mehulsatardekar/Collaborative-ide/blob/main/screenshots/loginroom3.png" width="500">
    <img src="https://github.com/mehulsatardekar/Collaborative-ide/blob/main/screenshots/google_login.png" width="500">
</p>


<p align="center"><b>Home Section</b>:tv:</p>
<p float="left">
  <img src="https://github.com/mehulsatardekar/Collaborative-ide/blob/main/screenshots/sidebar_ide.png" width="500">
  <img src="https://github.com/mehulsatardekar/Collaborative-ide/blob/main/screenshots/Joinroom.png" width="500">  
</p>

<p align="center"><b>Interview.io in an action</b>:tv:</p>
<img src="https://github.com/mehulsatardekar/Collaborative-ide/blob/main/screenshots/captured.gif" width="100%">

## To Run this project :clipboard:
<ul>
  <li>clone this project / download</li>
  <li>cd /project file</li>
  <li> npm install -- it will install all node modules which required to run this project</li>
  <li>npm start </li>
</ul>

<a href="https://www.youtube.com/watch?v=yuNHBj5av3g&t=4s" target="_blank#" >See the live demo of this project on youtube :sunglasses: </a>
