### ⛵✈🕸
# sailplane-web
Collaborative p2p file sharing in the browser

[![homepage](./imgs/homepage.png?raw=true)](https://cypsela.github.io/sailplane-web/)

live on github pages: https://cypsela.github.io/sailplane-web/

> uses [sailplane-node](https://github.com/cypsela/sailplane-node)

**clone and install:**
```
git clone https://github.com/cypsela/sailplane-web.git &&
cd sailplane-web &&
yarn
```

**build:**
```
yarn build
```

**dev server:**
```
yarn start
```
