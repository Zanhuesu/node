/// <reference types="react-scripts" />
declare module '*.svg';
declare module '*.mp3';
declare module 'react-scroll-to-bottom';
