import Snippet from 'components/Snippet';
import React from 'react';

const SnippetPage = () => {
    return (
        <>
            <Snippet />
        </>
    );
};

export default SnippetPage;
