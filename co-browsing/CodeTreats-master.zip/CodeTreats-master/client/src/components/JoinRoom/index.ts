import JoinRoom from './JoinRoom';
export default JoinRoom;
