export { default as IconPython } from './python';
export { default as IconJavascript } from './javascript';
export { default as IconTypescript } from './typescript';
export { default as IconCpp } from './cpp';
export { default as IconC } from './c';
export { default as IconGo } from './go';
export { default as IconJava } from './java';
export { default as IconCSharp } from './csharp';

export { default as FormattedIcon } from './_formattedIcon';
