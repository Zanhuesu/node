import InputPanel from './InputPanel';
export default InputPanel;
