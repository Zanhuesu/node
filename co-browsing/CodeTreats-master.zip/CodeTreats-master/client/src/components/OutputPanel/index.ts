import OutputPanel from './OutputPanel';
export default OutputPanel;
