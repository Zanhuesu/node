import SnippetsList from './SnippetsList';
export default SnippetsList;
