import Snippet from './Snippet';
export default Snippet;
