import LeaveRoom from './LeaveRoom';
export default LeaveRoom;
