import RoomLang from './RoomLang';
export default RoomLang;
