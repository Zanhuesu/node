import RoomInput from './RoomInput';
export default RoomInput;
