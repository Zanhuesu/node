import RoomInfo from './RoomInfo';
export default RoomInfo;
