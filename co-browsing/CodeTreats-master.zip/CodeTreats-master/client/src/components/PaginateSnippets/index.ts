import PaginateSnippets from './PaginateSnippets';
export default PaginateSnippets;
