const languageOptions = [
    {
        label: 'Python',
        value: 'python',
    },
    {
        label: 'Javascript',
        value: 'javascript',
    },
    {
        label: 'Typescript',
        value: 'typescript',
    },
    {
        label: 'C',
        value: 'c',
    },
    {
        label: 'C++',
        value: 'cpp',
    },
    {
        label: 'Go',
        value: 'go',
    },
    {
        label: 'Java',
        value: 'java',
    },
    {
        label: 'C#',
        value: 'csharp',
    },
];

export default languageOptions;
