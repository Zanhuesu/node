// See more here
// https://github.com/conventional-changelog/commitlint/tree/master/@commitlint/config-conventional
module.exports = { extends: ['@commitlint/config-conventional'] }
