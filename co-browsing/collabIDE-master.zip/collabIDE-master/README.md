# CollabIDE
The IDE for collaborative development, automatic versioning and contributions management.  

Link to the IDE's website: https://collabide.herokuapp.com/

Link to conference paper: https://www.researchgate.net/publication/326844516_A_collaborative_IDE_for_dynamic_multi-versioning_and_variant_management
